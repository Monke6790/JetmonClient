package jetmon.gui;

import jetmon.JetmonClient;
import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final int HEAD_H = 18;
    private static final int ROW_H = 14;
    private static final int GAP = 8;
    private static final int TOP = 40;
    private static final int RADIUS = 6;

    // warna (ARGB)
    private static final int COL_BODY = 0xA0B58CD9;       // ungu transparan
    private static final int COL_HEAD = 0xD02A1240;       // ungu gelap
    private static final int COL_HOVER = 0x40FFFFFF;
    private static final int COL_ACCENT = 0xFFFF2BD6;     // pink/magenta
    private static final int COL_TEXT = 0xFFFFFFFF;
    private static final int COL_TEXT_ON = 0xFFFF6BE6;
    private static final int COL_PILL = 0xA0583A7A;

    public ClickGui() {
        super(Component.literal("Jetmon"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private List<Category> categories() {
        List<Category> out = new ArrayList<>();
        for (Category c : Category.values()) {
            if (!JetmonClient.MODULES.in(c).isEmpty()) out.add(c);
        }
        return out;
    }

    private int panelWidth(int count) {
        int avail = this.width - 16 - GAP * (count - 1);
        return Math.max(70, Math.min(130, avail / Math.max(1, count)));
    }

    private int startX(int count, int pw) {
        int total = count * pw + (count - 1) * GAP;
        return Math.max(4, (this.width - total) / 2);
    }

    /** Persegi dengan sudut membulat, hanya memakai fill(). */
    private static void roundRect(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        g.fill(x, y + r, x + w, y + h - r, color);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);

        List<Category> cats = categories();
        int count = cats.size();
        int pw = panelWidth(count);
        int x = startX(count, pw);

        for (Category c : cats) {
            List<Module> mods = JetmonClient.MODULES.in(c);
            int bodyH = HEAD_H + mods.size() * ROW_H + 6;

            // badan panel
            roundRect(g, x, TOP, pw, bodyH, RADIUS, COL_BODY);

            // header (atas membulat, bawah lurus)
            roundRect(g, x, TOP, pw, HEAD_H, RADIUS, COL_HEAD);
            g.fill(x, TOP + HEAD_H / 2, x + pw, TOP + HEAD_H, COL_HEAD);
            String title = c.label.toUpperCase();
            g.text(this.font, title, x + (pw - this.font.width(title)) / 2, TOP + 5, COL_TEXT, true);

            int y = TOP + HEAD_H + 3;
            for (Module m : mods) {
                boolean hover = mouseX >= x && mouseX < x + pw && mouseY >= y && mouseY < y + ROW_H;
                if (hover) roundRect(g, x + 3, y, pw - 6, ROW_H, 3, COL_HOVER);
                if (m.isEnabled()) g.fill(x + 3, y + 2, x + 5, y + ROW_H - 2, COL_ACCENT);

                g.text(this.font, m.name.toUpperCase(), x + 10, y + 3,
                    m.isEnabled() ? COL_TEXT_ON : COL_TEXT, true);
                y += ROW_H;
            }
            x += pw + GAP;
        }

        // pil di bawah
        String label = "JETMON CLIENT";
        int pillW = Math.min(this.width - 20, 200);
        int pillX = (this.width - pillW) / 2;
        int pillY = this.height - 40;
        roundRect(g, pillX, pillY, pillW, 18, 8, COL_PILL);
        g.text(this.font, label, (this.width - this.font.width(label)) / 2, pillY + 5, COL_TEXT, true);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);

        List<Category> cats = categories();
        int count = cats.size();
        int pw = panelWidth(count);
        int x = startX(count, pw);

        for (Category c : cats) {
            int y = TOP + HEAD_H + 3;
            for (Module m : JetmonClient.MODULES.in(c)) {
                if (mx >= x && mx < x + pw && my >= y && my < y + ROW_H) {
                    m.toggle();
                    return true;
                }
                y += ROW_H;
            }
            x += pw + GAP;
        }
        return super.mouseClicked(event, doubleClick);
    }
}
