package jetmon.gui;

import jetmon.JetmonClient;
import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;

public class ClickGui extends Screen {
    private static final int PANEL_W = 110;
    private static final int HEAD_H = 14;
    private static final int ROW_H = 12;
    private static final int GAP = 4;
    private static final int TOP = 20;

    private static final int COL_HEADER = 0xFF8A2BE2;
    private static final int COL_ROW = 0xB0000000;
    private static final int COL_ROW_HOVER = 0xB0303030;
    private static final int COL_ON = 0xD05B21B6;

    public ClickGui() {
        super(Component.literal("Jetmon"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);

        g.text(this.font, "Jetmon Client", 6, 5, 0xFFFFFFFF, true);

        int x = 6;
        for (Category c : Category.values()) {
            List<Module> mods = JetmonClient.MODULES.in(c);
            if (mods.isEmpty()) continue;

            g.fill(x, TOP, x + PANEL_W, TOP + HEAD_H, COL_HEADER);
            g.text(this.font, c.label,
                x + (PANEL_W - this.font.width(c.label)) / 2, TOP + 3, 0xFFFFFFFF, true);

            int y = TOP + HEAD_H;
            for (Module m : mods) {
                boolean hover = mouseX >= x && mouseX < x + PANEL_W && mouseY >= y && mouseY < y + ROW_H;
                int bg = m.isEnabled() ? COL_ON : (hover ? COL_ROW_HOVER : COL_ROW);
                g.fill(x, y, x + PANEL_W, y + ROW_H, bg);
                g.text(this.font, m.name,
                    x + (PANEL_W - this.font.width(m.name)) / 2, y + 2, 0xFFFFFFFF, true);
                y += ROW_H;
            }
            x += PANEL_W + GAP;
        }

        g.text(this.font, "Left click - Toggle module", 4, this.height - 12, 0xFFAAAAAA, true);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);

        int x = 6;
        for (Category c : Category.values()) {
            List<Module> mods = JetmonClient.MODULES.in(c);
            if (mods.isEmpty()) continue;

            int y = TOP + HEAD_H;
            for (Module m : mods) {
                if (mx >= x && mx < x + PANEL_W && my >= y && my < y + ROW_H) {
                    m.toggle();
                    return true;
                }
                y += ROW_H;
            }
            x += PANEL_W + GAP;
        }
        return super.mouseClicked(event, doubleClick);
    }
}
