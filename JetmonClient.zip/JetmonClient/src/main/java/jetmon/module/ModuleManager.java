package jetmon.module;

import com.mojang.blaze3d.platform.InputConstants;
import jetmon.gui.ClickGui;
import jetmon.module.modules.*;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Map<Module, KeyMapping> moduleKeys = new LinkedHashMap<>();
    private KeyMapping guiKey;

    public ModuleManager() {
        // Movement
        modules.add(new Sprint());     // J
        modules.add(new Fly());        // L
        modules.add(new AutoJump());
        modules.add(new AutoWalk());
        modules.add(new Sneak());
        // Player
        modules.add(new AutoRespawn());
        modules.add(new AntiAfk());
        // Render
        modules.add(new Fullbright()); // K
        modules.add(new Zoom());
    }

    /** Dipanggil sekali dari onInitializeClient. Keybind bisa diubah di Options > Controls > Key Binds. */
    public void registerKeys() {
        KeyMapping.Category category = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath("jetmon", "main"));

        guiKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.jetmon.gui", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        for (Module m : modules) {
            if (m.keyCode > 0) {
                String id = "key.jetmon." + m.name.toLowerCase().replace(' ', '_');
                moduleKeys.put(m, KeyMappingHelper.registerKeyMapping(new KeyMapping(
                    id, InputConstants.Type.KEYSYM, m.keyCode, category)));
            }
        }
    }

    public List<Module> all() {
        return modules;
    }

    public List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == c) out.add(m);
        return out;
    }

    public void tick(Minecraft mc) {
        while (guiKey != null && guiKey.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new ClickGui());
        }

        for (Map.Entry<Module, KeyMapping> e : moduleKeys.entrySet()) {
            while (e.getValue().consumeClick()) {
                if (mc.player != null) e.getKey().toggle();
            }
        }

        if (mc.player == null || mc.level == null) return;
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick(mc);
        }
    }
}
