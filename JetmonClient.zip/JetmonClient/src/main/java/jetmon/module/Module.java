package jetmon.module;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public abstract class Module {
    public final String name;
    public final Category category;
    public final int keyCode; // GLFW key code, -1 = tanpa keybind
    private boolean enabled;

    protected Module(String name, Category category, int keyCode) {
        this.name = name;
        this.category = category;
        this.keyCode = keyCode;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        enabled = !enabled;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            if (enabled) onEnable(mc); else onDisable(mc);
            mc.player.sendSystemMessage(
                Component.literal("[Jetmon] " + name + (enabled ? " ON" : " OFF")));
        }
    }

    protected void onEnable(Minecraft mc) {}
    protected void onDisable(Minecraft mc) {}
    public void onTick(Minecraft mc) {}
}
