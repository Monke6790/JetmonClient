package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.Minecraft;

public class AutoWalk extends Module {
    public AutoWalk() { super("Auto Walk", Category.MOVEMENT, -1); }

    @Override
    public void onTick(Minecraft mc) { mc.options.keyUp.setDown(true); }

    @Override
    protected void onDisable(Minecraft mc) { mc.options.keyUp.setDown(false); }
}
