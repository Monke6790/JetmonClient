package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import jetmon.util.Scan;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;

import java.util.HashSet;
import java.util.Set;

/** Memberi tahu lewat chat setiap kali ada spawner baru di chunk sekitar. */
public class SpawnerNotifier extends Module {
    private static final int RADIUS_CHUNKS = 6;

    private final Set<Long> seen = new HashSet<>();
    private Object lastLevel;
    private int ticks;

    public SpawnerNotifier() {
        super("Spawner Notifier", Category.RENDER, -1);
    }

    @Override
    protected void onDisable(Minecraft mc) {
        seen.clear();
        lastLevel = null;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level != lastLevel) {
            seen.clear();
            lastLevel = mc.level;
        }
        if (++ticks % 20 != 0) return;

        for (BlockEntity be : Scan.nearby(mc, RADIUS_CHUNKS)) {
            if (!(be instanceof SpawnerBlockEntity)) continue;
            long key = be.getBlockPos().asLong();
            if (!seen.add(key)) continue;

            int x = be.getBlockPos().getX();
            int y = be.getBlockPos().getY();
            int z = be.getBlockPos().getZ();
            mc.player.sendSystemMessage(Component.literal(
                "[Jetmon] Spawner ditemukan di " + x + " " + y + " " + z
                    + " (" + Scan.distance(mc, x, y, z) + " blok)"));
        }
    }
}
