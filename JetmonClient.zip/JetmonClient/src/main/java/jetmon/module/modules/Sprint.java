package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.MOVEMENT, GLFW.GLFW_KEY_J); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.options.keyUp.isDown()) mc.options.keySprint.setDown(true);
    }

    @Override
    protected void onDisable(Minecraft mc) { mc.options.keySprint.setDown(false); }
}
