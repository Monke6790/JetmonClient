package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.Minecraft;

public class AutoRespawn extends Module {
    public AutoRespawn() { super("Auto Respawn", Category.PLAYER, -1); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player.isDeadOrDying()) mc.player.respawn();
    }
}
