package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class Fly extends Module {
    public Fly() { super("Fly", Category.MOVEMENT, GLFW.GLFW_KEY_L); }

    @Override
    public void onTick(Minecraft mc) {
        var abilities = mc.player.getAbilities();
        abilities.mayfly = true;
        abilities.flying = true;
    }

    @Override
    protected void onDisable(Minecraft mc) {
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            var abilities = mc.player.getAbilities();
            abilities.mayfly = false;
            abilities.flying = false;
        }
    }
}
