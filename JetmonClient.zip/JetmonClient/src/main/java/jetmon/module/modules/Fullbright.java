package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import org.lwjgl.glfw.GLFW;

public class Fullbright extends Module {
    public Fullbright() { super("Fullbright", Category.RENDER, GLFW.GLFW_KEY_K); }

    @Override
    public void onTick(Minecraft mc) {
        mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1000, 0, false, false));
    }

    @Override
    protected void onDisable(Minecraft mc) { mc.player.removeEffect(MobEffects.NIGHT_VISION); }
}
