package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import jetmon.util.Scan;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Mendeteksi wadah penyimpanan (chest, barrel, shulker, ender chest, hopper, dispenser/dropper)
 * di chunk sekitar dan melaporkan jenis, koordinat, dan jaraknya lewat chat.
 */
public class StorageEsp extends Module {
    private static final int RADIUS_CHUNKS = 6;
    private static final int MAX_INDIVIDUAL = 5;

    private final Set<Long> seen = new HashSet<>();
    private Object lastLevel;
    private int ticks;

    public StorageEsp() {
        super("Storage ESP", Category.RENDER, -1);
    }

    @Override
    protected void onDisable(Minecraft mc) {
        seen.clear();
        lastLevel = null;
    }

    private static String typeName(BlockEntity be) {
        if (be instanceof EnderChestBlockEntity) return "Ender Chest";
        if (be instanceof ChestBlockEntity) return "Chest";
        if (be instanceof BarrelBlockEntity) return "Barrel";
        if (be instanceof ShulkerBoxBlockEntity) return "Shulker Box";
        if (be instanceof HopperBlockEntity) return "Hopper";
        if (be instanceof DispenserBlockEntity) return "Dispenser/Dropper";
        return null;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level != lastLevel) {
            seen.clear();
            lastLevel = mc.level;
        }
        if (++ticks % 20 != 0) return;

        List<String> found = new ArrayList<>();
        for (BlockEntity be : Scan.nearby(mc, RADIUS_CHUNKS)) {
            String type = typeName(be);
            if (type == null) continue;
            if (!seen.add(be.getBlockPos().asLong())) continue;

            int x = be.getBlockPos().getX();
            int y = be.getBlockPos().getY();
            int z = be.getBlockPos().getZ();
            found.add(type + " di " + x + " " + y + " " + z
                + " (" + Scan.distance(mc, x, y, z) + " blok)");
        }

        if (found.isEmpty()) return;

        if (found.size() <= MAX_INDIVIDUAL) {
            for (String line : found) {
                mc.player.sendSystemMessage(Component.literal("[Jetmon] " + line));
            }
        } else {
            mc.player.sendSystemMessage(Component.literal(
                "[Jetmon] " + found.size() + " storage baru ditemukan. Contoh: " + found.get(0)));
        }
    }
}
