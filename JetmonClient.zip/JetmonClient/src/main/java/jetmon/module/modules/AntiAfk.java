package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.Minecraft;

public class AntiAfk extends Module {
    private int ticks;

    public AntiAfk() { super("Anti Afk", Category.PLAYER, -1); }

    @Override
    public void onTick(Minecraft mc) {
        ticks++;
        // lompat sebentar tiap ~20 detik
        mc.options.keyJump.setDown(ticks % 400 < 2);
    }

    @Override
    protected void onDisable(Minecraft mc) {
        ticks = 0;
        mc.options.keyJump.setDown(false);
    }
}
