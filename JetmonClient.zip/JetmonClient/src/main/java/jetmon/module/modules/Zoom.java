package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.Minecraft;

public class Zoom extends Module {
    private int oldFov = 70;

    public Zoom() { super("Zoom", Category.RENDER, -1); }

    @Override
    protected void onEnable(Minecraft mc) { oldFov = mc.options.fov().get(); }

    @Override
    public void onTick(Minecraft mc) { mc.options.fov().set(30); }

    @Override
    protected void onDisable(Minecraft mc) { mc.options.fov().set(oldFov); }
}
