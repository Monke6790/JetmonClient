package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.Minecraft;

public class Sneak extends Module {
    public Sneak() { super("Sneak", Category.MOVEMENT, -1); }

    @Override
    public void onTick(Minecraft mc) { mc.options.keyShift.setDown(true); }

    @Override
    protected void onDisable(Minecraft mc) { mc.options.keyShift.setDown(false); }
}
