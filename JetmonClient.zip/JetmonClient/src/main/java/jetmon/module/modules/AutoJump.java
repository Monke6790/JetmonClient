package jetmon.module.modules;

import jetmon.module.Category;
import jetmon.module.Module;
import net.minecraft.client.Minecraft;

public class AutoJump extends Module {
    public AutoJump() { super("Auto Jump", Category.MOVEMENT, -1); }

    @Override
    public void onTick(Minecraft mc) {
        mc.options.keyJump.setDown(mc.player.onGround() && mc.options.keyUp.isDown());
    }

    @Override
    protected void onDisable(Minecraft mc) { mc.options.keyJump.setDown(false); }
}
