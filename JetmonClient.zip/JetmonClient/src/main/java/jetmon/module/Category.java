package jetmon.module;

public enum Category {
    MOVEMENT("Movement"),
    PLAYER("Player"),
    RENDER("Render"),
    MISC("Misc");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
