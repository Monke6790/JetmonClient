package jetmon.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.ArrayList;
import java.util.List;

public final class Scan {
    private Scan() {}

    /** Semua block entity di chunk yang sudah dimuat klien, dalam radius chunk dari pemain. */
    public static List<BlockEntity> nearby(Minecraft mc, int radiusChunks) {
        List<BlockEntity> out = new ArrayList<>();
        if (mc.player == null || mc.level == null) return out;

        int pcx = mc.player.blockPosition().getX() >> 4;
        int pcz = mc.player.blockPosition().getZ() >> 4;

        for (int dx = -radiusChunks; dx <= radiusChunks; dx++) {
            for (int dz = -radiusChunks; dz <= radiusChunks; dz++) {
                LevelChunk chunk = mc.level.getChunk(pcx + dx, pcz + dz);
                out.addAll(chunk.getBlockEntities().values());
            }
        }
        return out;
    }

    public static int distance(Minecraft mc, int x, int y, int z) {
        int dx = x - mc.player.blockPosition().getX();
        int dy = y - mc.player.blockPosition().getY();
        int dz = z - mc.player.blockPosition().getZ();
        return (int) Math.sqrt((double) dx * dx + (double) dy * dy + (double) dz * dz);
    }
}
