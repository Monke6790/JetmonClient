package jetmon;

import jetmon.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class JetmonClient implements ClientModInitializer {
    public static final String NAME = "Jetmon";
    public static final ModuleManager MODULES = new ModuleManager();

    @Override
    public void onInitializeClient() {
        MODULES.registerKeys();
        ClientTickEvents.END_CLIENT_TICK.register(MODULES::tick);
    }
}
