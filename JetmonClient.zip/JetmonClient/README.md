# Jetmon Client (Minecraft Java 26.1.2, Fabric)

Right Shift = buka ClickGUI (klik kiri = toggle modul). Semua keybind bisa diubah di Options > Controls > Key Binds > "Jetmon Client".
Keybind langsung: J = Sprint, K = Fullbright, L = Fly

Modul: Sprint, Fly, Auto Jump, Auto Walk, Sneak, Auto Respawn, Anti Afk, Fullbright, Zoom

## Build
Butuh JDK 25. Lokal: `gradle wrapper --gradle-version 9.4.0` lalu `./gradlew build`.
Tanpa install: upload ke GitHub (termasuk folder .github), tab Actions -> download artifact jetmon-client-jar.

## Tambah modul
Buat kelas baru extends `Module` di `jetmon/module/modules`, daftarkan di `ModuleManager`.
